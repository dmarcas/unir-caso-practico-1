import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='davidmarcas',
    application_name='todo-list-serverless',
    app_uid='sktq5SKVWKVjs5SbN9',
    org_uid='1a08f156-0327-4a16-9297-7fc63a508a9b',
    deployment_uid='6d5f152d-560c-4179-a224-3242c9cde4d1',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-delete', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/delete.delete')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
